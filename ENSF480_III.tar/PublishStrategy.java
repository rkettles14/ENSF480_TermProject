/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Zach Sims, Rylan Kettles, Brandon Khoo
 */
public interface PublishStrategy {
    abstract void publish();
}
